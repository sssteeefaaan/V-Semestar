export class Radnik {

  constructor(id, ime, plata, godineRadnogStaza) {
    this.id = id;
    this.ime = ime;
    this.plata = plata;
    this.godineRadnogStaza = godineRadnogStaza;
  }
}