var str = ["Dare", "je", "najbolji", "JS", "programer"]

console.log("Konkatenacija stringova:")
console.log(str.reduce((acc, curr) => acc + ' - ' + curr, ''))
