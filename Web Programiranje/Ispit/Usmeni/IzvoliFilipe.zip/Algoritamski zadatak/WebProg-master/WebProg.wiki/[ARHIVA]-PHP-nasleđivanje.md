Ključna reč kojom se označava da jedna klasa nasleđuje drugu je **extends**. Dozvoljeno je samo jednostruko nasleđivanje. Nasleđeni atributi i metode se mogu preklopiti u izvedenoj klasi (override), tako što se deklarišu atributi i metode sa istim imenom kao u osnovnoj.

Metodama osnovne klase se stavlja modifikator **final** da bi se zabranilo preklapanje. Preklopljenim atributima i metodama osnovne klase se pristupa sa `parent::<attr_ili_metoda>`.

Konstruktor je metoda koja se definiše `__construct(<listaArgumenata>)`
Konstruktor izvedene klase **NE** zove automatski konstruktor osnovne klase. **Ne postoji oveloading funkcija, pa klase mogu imati samo jedan konstruktor.**

Destriktor je metoda oblika `__destruct()`. **Destruktor izvedene klase NE zove automatski destruktor osnovne.**

[43. ORM alati](43.-ORM-alati)