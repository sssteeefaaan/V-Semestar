Koristi se ključna reč class, nakon nje sledi ime klase. Telo klase se nalazi imeđu para vitičastih zagrada.

```php 
class Macka {
    public $ime = 'Flafi';
    
    public function mjaukni(){
        echo 'mjau';
    }
    public function ime Macke() {
        return $this->ime;
    }
}
```
`$this` - nestatičkim atributima se iz konteksta klase pritupa pomoću `$this->imeAtributa`

Statičkim atributima se iz konteksta klase pristupa pomoću self::imeAtributa. Atributi klase imaju 3 modifikatora pristupa:

* public
* private
* protected

Postoje 2 načina za pozivanje konstruktora:

* direktno

```php
$obj = new Macka();
$obj->mjaukni();
```
* preko promenljive

```php
$imeKlase='Macka';
$obj2 = new $imeKlase();
$obj2->mjaukni();
```

Pored globalnih konstanti, moguće je zadati konstante u okviru klase. KLjučnom rečju **const**. Naziv konstante nema $. Pristup iz konsteksta klase - `self::KONSTANTA`
Pristup van klase - `imeKlase::KONSTANTA`
Atributi i metode mogu da imaju isti naziv. `$this` nije dostupno u okviru statičke metode. 

Statičkim metodama možemo pristupati sa:

* `$promenljiva->imeMetode()`
* `$klasa::imeMetode()`

Statičkim atributima se pristupa samo sa ::

* `$klasa::staticAttribut`
* `$promenljiva::staticAttribut`

Postoje i apstraktne klase u PHP-u koje se ne mogu instancirati. Klase koje imaju bar jednu apstraktu metodu moraju biti apstraktne. Kad konkretna klasa nasleđuje apstraktnu, apstraktne metode roditeljske klase moraju biti definisane. Metoda implemetirana u izvedenoj klasi mora biti **istog** ili **višeg** stepena vidljivosti u odnosu na apstranu metodu u osnovnoj klasi (protected u osnovnoj, protected ili public u izvedenoj).

Interfejsi zadaju samo metode koje klase trebaju da implementiraju, bez specifikacije kako treba implementirati metoda. Ključna reč je **intreface**. Sve metode interfejsa moraju biti javne (explicitno pisanjem public, ili podrazumevano bez pisanja moda pristupa). Ključna reč **implements** specificira da klasa implementira interfejs. Interfejsi mogu međusobno da se nasleđuju (ključna reč **extends**). Klasa može da implementira više interfejsa (odvajaju se zarezom). Interfejs može da sadrži konstantu, a klasa koja implementira taj interfejs, NE može da predefiniše tu konstantu.

[42. PHP nasleđivanje](42.-PHP-nasleđivanje)