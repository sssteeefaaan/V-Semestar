Superglobalne promenljive koje definiše sam PHP. Zavisno od parametara prosleđenih kroz HTTP zahtev i okruženja superglobalne promenljive imaju različitu vrednost. Uvek su dostupne. Može im se pristupati iz bilo koje funkcije, klase ili fajla. Ima ih 9:

1. $GLOBALS- koristi se za čuvanje svih globalnih promenljivih iz bilo kog dela PHP skripte

```php
$x=75;
$y=43;

function add(){
    $GLOBALS['z'] = $GLOBALS['x'] + $GLOBALS['y'];
}

add();
echo $z;
```

2. $_SERVER - sadrži informacije o hederima, putanjama i lokacijama skripti
```php
#_SERVER['SERVER_NAME']//vraća ime servera
```
3. $_POST - sadrži informacije poslate sa klijenta preko POST metode
4. $_GET - sadrži informacije poslate sa klijenta preko GET metode
5. $_FILES
6. $_ENV
7. $_COOKIE
8. $_SESSION
9. $_REQUEST - sadrži informacije poslate sa klijenta preko GET i POST metode

[40. Prenos podataka sa klijenta na server](40.-Prenos-podataka-sa-klijenta-na-server)