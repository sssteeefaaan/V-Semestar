import { Trougao } from "./trougao.js";

const t = new Trougao("Pascal");

const t2 = new Trougao("n");
t.crtaj(document.body);
t2.crtaj(document.body);