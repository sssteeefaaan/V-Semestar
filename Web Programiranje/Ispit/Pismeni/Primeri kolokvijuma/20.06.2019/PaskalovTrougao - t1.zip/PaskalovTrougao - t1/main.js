import { Trougao } from "./trougao.js";


const trougao = new Trougao(5, "Cas");
trougao.crtaj(document.body);