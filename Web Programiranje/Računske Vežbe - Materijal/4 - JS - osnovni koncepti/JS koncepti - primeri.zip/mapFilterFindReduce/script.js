let array = [1, 4, 9, 16];
console.log(array);
let arrayMap1 = array.map(x => x * 2)
console.log(arrayMap1);

let arrayMap2 = array.map((x) => {
    return x * 2;
})
console.log(arrayMap2);

let arrayMap3 = array.map(function(x){
    return x * 2;
})
console.log(arrayMap3);


let X = 6;
let words = ['spray', 'destruction', 'present',
            'exuberant', 'limit', 'elite',];
console.log(words);
const resultFilter1 = words.filter(word => word.length > X);
console.log(resultFilter1);

const resultFilter2 = words.filter(isLongerThanX);
console.log(resultFilter2);
function isLongerThanX(string)
{
    return string.length > X;
}


let arrayNum = [5, 12, 8, 130, 44];
const found = arrayNum.find(el => el > 10);
console.log(found);


const arrayNumbers = [1, 2, 3, 4];
const sum1 = arrayNumbers.reduce((accumulator, currentValue) => accumulator + currentValue);
console.log(sum1);
const sum2 = arrayNumbers.reduce((accumulator, currentValue) => {
    return accumulator += currentValue;
    }, 5)
console.log(sum2);



