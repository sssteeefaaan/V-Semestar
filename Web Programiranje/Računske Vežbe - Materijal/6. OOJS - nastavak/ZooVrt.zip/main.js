import {Vrt} from "./vrt.js"

const vrt1 = new Vrt("Zoo vrt", 5,4,6);
vrt1.crtajVrt(document.body);


const vrt2 = new Vrt("Drugi vrt", 10,10,20);
vrt2.crtajVrt(document.body);