export class Brojac{

    constructor(vrednost){
        this.trVrednost=vrednost;
    }

    crtaj(host){
        if(!host)
            throw new Error("Host ne postoji");
        const dugme = document.createElement("button");
        dugme.classList.add("brojac"); //dugme.className ="brojac";
        dugme.innerHTML=this.trVrednost;
        host.appendChild(dugme);
        dugme.onclick =(ev)=>{
            this.smanji(dugme);
        }
        
    }

    smanji(domElement){
        this.trVrednost--;
        
        domElement.innerHTML=this.trVrednost;
        if(this.trVrednost===0)
            domElement.classList.add("crveno");
    }



}