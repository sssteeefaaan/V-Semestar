import {Brojac} from "./brojac.js"

const brojac=new Brojac(10);
brojac.crtaj(document.body);

const brojac1=new Brojac(5);
brojac1.crtaj(document.body);