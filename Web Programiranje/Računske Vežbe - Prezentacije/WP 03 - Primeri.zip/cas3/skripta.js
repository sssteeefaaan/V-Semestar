document.body.onload
{
    let panel=document.querySelector("#panel");

    let nizPolja=["Ime", "Prezime", "Index", "Pass", "Datum"];
    let nizTipova=["text", "text", "number","password", "date"];

    let imelab;
    let polje;
    nizPolja.forEach((el,i) =>{

        imelab= document.createElement("label");
        imelab.innerHTML=el;
        imelab.className="labela";
        imelab.classList.add("imelab");
        panel.appendChild(imelab);
    
        polje=document.createElement("input");
        polje.type=nizTipova[i];
        polje.className="poljeZaUnos";
        panel.appendChild(polje);


    })

    let dugme=document.createElement("button");
    dugme.innerHTML="Klikni";
    panel.appendChild(dugme);
    dugme.addEventListener("click", kliknuto);


    function kliknuto(){

        let nizlabela= document.querySelectorAll("label");

        let t="";
        nizlabela.forEach(el=>{
            t+=el.innerHTML+" ";
        })
        alert(t);
        console.log(nizlabela);
    } 



    



    


}